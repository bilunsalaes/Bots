_addon.name = 'CRB_addon'
_addon.author = 'Daniel_H'
_addon.version = '1.0'
_addon_description = ''

function send_required_string(ServerID, currentRoll)
    if windower then
        windower.send_command('crb_addon ' .. ServerID .. ' ' .. currentRoll)
    elseif ashita then
        AshitaCore:GetChatManager():QueueCommand('//crb_addon ' .. ServerID .. ' ' .. currentRoll, -1); 
    end
end

if windower then

    zoning_bool = false; 

    -- BEGIN WINDOWER CODE ---------------------------------------------------------------------------------
    
    packets = require("packets") 

    local player = windower.ffxi.get_player()

    windower.register_event('action', function (data)
        if data.target_count > 0 and data.category == 6 then 
            local actor = windower.ffxi.get_mob_by_id(data.actor_id)

            if actor.in_party or actor.in_alliance then
                current_roll = data.targets[1].actions[1].param; 
                send_required_string(actor.index, current_roll)

            end
        end
    end)

    -- END WINDOWER CODE -----------------------------------------------------------------------------------

elseif ashita then

    -- BEGIN ASHITA CODE -----------------------------------------------------------------------------------

    ashita.register_event('incoming_packet', function(id, size, data)

        actorName = "None"; 

        if id == 0xB then
            zoning_bool = true
        elseif id == 0xA and zoning_bool then
            zoning_bool = false
        end

        if not zoning_bool then 

            if id == 0x28 then
                actorName = "None" -- Always set to None to reset the name

                local party = AshitaCore:GetDataManager():GetParty(); 
                local player = AshitaCore:GetDataManager():GetPlayer(); 
                local actor = struct.unpack('I', data, 6); 
                local category = ashita.bits.unpack_be(data, 82, 4); 
                local effect = ashita.bits.unpack_be(data, 213, 17); 
                
                -- It's a job ability
                if category == 6 then
                    --local prop = ashita.bits.unpack_be(data, 272, 6); 
                    if effect then
                        if (actor == party:GetMemberServerId(0)) then
                            send_required_string(actor, effect)
                        end
                    end
                end
            end
        end
        return false; 
    end); 
    
    -- END ASHITA CODE -------------------------------------------------------------------------------------

end

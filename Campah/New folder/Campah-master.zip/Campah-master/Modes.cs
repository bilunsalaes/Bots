﻿namespace CampahApp
{
    public enum Modes
    {
        Stopped,
        Error,
        Buying,
        Selling,
        Updating
    }
}
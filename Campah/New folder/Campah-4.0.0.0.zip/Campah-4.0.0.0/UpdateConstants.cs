using System;

namespace CampahApp
{
    public static class UpdateConstants
    {
        public const String UpdateUrl = "http://gs.1942.net/downloads/";
        public const String UpdateFolder = "UpdateFiles";
    }
}